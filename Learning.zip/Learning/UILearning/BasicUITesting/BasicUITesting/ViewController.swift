//
//  ViewController.swift
//  BasicUITesting
//
//  Created by Rajeshwaran Sarangarajan on 29/10/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func showPopUp(sender : UIButton){
        var superHero = Marvel(heroType: .Thor)
        superHero.getCatchPhrase()
        let alert = UIAlertController (title: "UI Testing", message: superHero.catchPhrase, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        present(alert,animated: true,completion: nil)
    }


}

