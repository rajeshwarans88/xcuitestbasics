//
//  BasicUITestingUITests.swift
//  BasicUITestingUITests
//
//  Created by Rajeshwaran Sarangarajan on 29/10/22.
//

import XCTest

class BasicUITestingUITests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.

        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false

        // In UI tests it’s important to set the initial state - such as interface orientation - required for your tests before they run. The setUp method is a good place to do this.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // UI tests must launch the application that they test.
        let app = XCUIApplication()
        app.launch()

        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func test_Record() {
        
        let app = XCUIApplication()
        app.launch()
        app.textFields["txtDemo"].tap()
        app.textFields["txtDemo"].typeText("Automation Trial")
        app.buttons["btnSubmit"].tap()
        XCTAssertTrue(app.alerts["UI Testing"].exists)
        app.alerts["UI Testing"].scrollViews.otherElements.buttons["OK"].tap()
        XCTAssertFalse(app.alerts["UI Testing"].exists)
    }
    
    func test_XCUIApplicationExample(){
        let app = XCUIApplication()
        app.launch()
        let fileApp = XCUIApplication(bundleIdentifier: "com.apple.DocumentsApp")
        let shortCutsApp = XCUIApplication(bundleIdentifier: "com.apple.shortcuts")
        fileApp.activate()
        shortCutsApp.launch()
        fileApp.terminate()
        shortCutsApp.terminate()
    }
    
    func test_ListAllButtons(){
        let app = XCUIApplication()
        app.launch()
        
        let btn = app.scrollViews.children(matching: .button)
        print(btn)
    }
    
    func test_XCTAssertSamples(){
        let app = XCUIApplication()
        XCTAssertTrue(true)
        XCTAssertFalse(false)
        XCTAssertNotNil(app)
        XCTAssertEqual(2*3, 6*1)
        XCTAssertNil(app)
    }
    
    func test_VerifyTextFieldBehaviour(){
        let testString = "Hello World"
        let app = XCUIApplication()
        let textField = app.textFields["txtDemo"]
        
        app.launch()
        textField.tap()
        textField.typeText(testString)
        
        if let valueEntered = textField.value {
            XCTAssertTrue(valueEntered as! String == testString)
            print(valueEntered)
        }
    }
}
