//
//  MarvelUnitTests.swift
//  BasicUITestingTests
//
//  Created by Rajeshwaran Sarangarajan on 30/10/22.
//

import XCTest
@testable import BasicUITesting
class MarvelUnitTests: XCTestCase {

    var superHero : Marvel?
    
    override func setUpWithError() throws {
        superHero = Marvel(heroType: .IronMan)
    }

    override func tearDownWithError() throws {
        superHero = nil
    }

    func testExample() throws {
        superHero?.getCatchPhrase()
        XCTAssertTrue(superHero?.catchPhrase == "I am IronMan")
    }
}
